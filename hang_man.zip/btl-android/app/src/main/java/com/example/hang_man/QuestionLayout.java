package com.example.hang_man;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.hangman.R;

public class QuestionLayout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question_layout);
    }
}
